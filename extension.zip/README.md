# English-Czech-Dictionary
Firefox Addon providing English to Czech translation
